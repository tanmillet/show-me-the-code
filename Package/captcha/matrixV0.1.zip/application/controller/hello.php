<?php
/*
  home.php
*/
class hello extends mt_controller{
  public function index(){
    echo 'This is the index function';
  }
  public function show(){
    echo 'This is the show function';
  }
}