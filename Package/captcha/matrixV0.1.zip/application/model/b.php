<?php

class b extends mt_model{
  public $test_var='Model B';
  public function test_func(){
    echo 'This is Model B';
  }
}