<?php

class a extends mt_model{
  public $test_var='Model A';
  public function test_func(){
    echo 'This is Model A';
  }
}