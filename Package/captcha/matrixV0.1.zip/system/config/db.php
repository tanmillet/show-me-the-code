<?php
/*
  db.php
  2014.7.31
  数据库配置文件
*/
defined('ENTRY') or die('Deny you!');
return $db_config=array(
  'type'=>'mysql',
  'host'=>'127.0.0.1',
  'username'=>'root',
  'password'=>'root',
  'db'=>'yuan'
);