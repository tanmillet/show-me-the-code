<?php
/*
  config.php
  2014.7.31
  全局通用配置文件
*/
defined('ENTRY') or die('Deny you!');

return $common_config=array();