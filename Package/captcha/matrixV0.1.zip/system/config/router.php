<?php
/*
  router.php
  2014.7.31
  全局路由配置文件
*/
defined('ENTRY') or die('Deny you!');

return $router_config=array(
  'default'=>'home'
);