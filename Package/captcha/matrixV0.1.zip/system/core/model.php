<?php
/*
  model.php
  2014.8.4
  加载类 
*/
class mt_model{
  public function __construct(){
    // 将新加载进来的model类添加为mt_controller的属性 ...
	
  }
}