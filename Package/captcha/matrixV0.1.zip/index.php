<?php
/*
  index.php
  单一入口首页
  2014.7.31
*/
// 定义全局常量 ...
define('ENTRY','true');
define('APP','application');
define('SYS','system');

// 载入核心逻辑文件 ...
require_once SYS.'/core/matrix.php';
